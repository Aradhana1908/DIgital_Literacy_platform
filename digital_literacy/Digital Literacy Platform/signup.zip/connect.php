<?php
    if(isset($_POST['submit'])) {
        $name= $_POST['name'];
        $email= $_POST['email'];
        $passwd= $_POST['password'];

        $conn= new mysqli('localhost','root','NO','digi_lit');
        if ($con) {
            $sql="insert into 'user_info'(name,email,passwd) 
            values('$name','$email','$passwd')" ;
            $result=mysqli_query($con,$sql);
            if ($result){
                echo 'Data enterd';
            }
        } else {
            die(mysqli_error($con));
        }
}
  
?>
